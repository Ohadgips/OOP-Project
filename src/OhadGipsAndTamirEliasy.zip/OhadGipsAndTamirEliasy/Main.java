package OhadGipsAndTamirEliasy;

import java.util.Scanner;
// Submitted By: Tamir Eliasy 216430298 & Ohad Gips 215426883
public class Main {
    public static void addLecturer(College college) {
        String input;boolean exists;
        Lecturer[] lecturers = college.getLecturers();
        Scanner sc = new Scanner(System.in);
        do {
            System.out.print("Enter Lecturer Name (to return enter 'return'): ");
            exists = false;
            input = sc.nextLine();
            if (!input.equals("return")){
                for (int i = 0; i < college.getLecturersSize(); i++) {
                    if (lecturers[i].getName().equals(input)) {
                        System.out.println("This name is already in use. Try a different name");
                        exists = true;
                        break;
                    }
                }
            }
        } while (exists);
        if (!input.equals("return")) {
            System.out.print("\nEnter lecturer ID: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.print("\nEnter kind of degree (Bachelor, Master, Doctoral): ");
            Lecturer.Degree kindOfDegree = Lecturer.Degree.valueOf(sc.nextLine());
            System.out.print("\nEnter name of degree: ");
            String degreeName = sc.nextLine();
            System.out.print("\nEnter lecturer wage: ");
            int wage = sc.nextInt();

            if (college.getLecturersSize() >= lecturers.length) {
                lecturers = Committee.resizeLecturers(lecturers);
                college.setLecturers(lecturers);
            }

            lecturers[college.getLecturersSize()] = new Lecturer(input, id, kindOfDegree, degreeName, wage);
            college.setLecturersSize(college.getLecturersSize()+1);
        }
    }
    public static void addCommittee(College college) {
        // without a doctoral lecturer you cannot create a committee
        if (college.HasDoctoralLecturer()) {
            boolean exists;
            String chairpersonName, name;
            Lecturer chairperson = null;
            Scanner sc = new Scanner(System.in);
            int committeeSize = college.getCommitteeSize();
            Committee[] committees = college.getCommittees();
            do {
                System.out.print("Enter committee name (to return enter 'return'): ");
                exists = false;
                name = sc.nextLine();
                if (!name.equals("return")) {
                    for (int i = 0; i < committeeSize; i++) {
                        if (committees[i].getName().equals(name)) {
                            System.out.println("\nThis committee is already exists. Try a different name");
                            exists = true;
                        }
                    }
                }
            } while (exists);
            if (!name.equals("return")) {
                do {
                    System.out.print("Enter chairperson name (to return enter 'return'): ");
                    exists = true;
                    chairpersonName = sc.nextLine();
                    if (chairpersonName.equals("return")) {
                        exists = false ;
                    }
                    else {
                        chairperson = college.getLecturer(chairpersonName);
                        if (chairperson != null) {
                            if (chairperson.getKindOfDegree() == Lecturer.Degree.Doctoral) {
                                exists = false;
                            } else {
                                System.out.println("This lecturer does not meet the requirements");
                            }
                        }
                    }
                } while (exists);
                if (!chairpersonName.equals("return")) {
                    if (committeeSize >= committees.length) {
                        committees = Lecturer.resizeCommittees(committees);
                        college.setCommittees(committees);
                    }
                    committees[committeeSize] = new Committee(name, chairperson);
                    chairperson.addCommittee(committees[committeeSize]);
                    college.setCommitteeSize(committeeSize + 1);
                    System.out.printf("%s has been created, %s it is chairperson\n", name, chairpersonName);
                }
            }
        } else System.out.println("There are no doctoral lecturers in the college to create a committee");

    }
    public static boolean LecturerAndCommitteeExists(Lecturer lecturer,Committee committee) {
        if (committee == null) {
            System.out.println("committee doesn't exists");
            return false;
        }
        if (lecturer == null) {
                System.out.println("lecturer doesn't exists");
                return false;
        }
        return true;
    }
    public static void addDepartment(College college){
        Department[] departments = college.getDepartments();
        int departmentsSize = college.getDepartmentsSize();
        String departmentName;
        Scanner sc = new Scanner(System.in);
        boolean exists;
        do {
            System.out.print("Enter department name (to return enter 'return'): ");
            departmentName = sc.nextLine();
            exists = false;
            if (!departmentName.equals("return")) {
                for (int i = 0; i < departmentsSize && !exists && departments[i].getName() != null; i++) {
                    if (departments[i].getName().equals(departmentName)) {
                        System.out.println("This department already exists. Try a different name.");
                        exists = true;
                    }
                }
            }
        } while (exists);
        if (!departmentName.equals("return")) {
            System.out.print("Enter number of students in the department: ");
            int numOfStudents = sc.nextInt();

            if (departmentsSize >= departments.length) {
                college.resizeDepartments();
                departments = college.getDepartments();
            }

            departments[departmentsSize] = new Department(departmentName, numOfStudents);
            departmentsSize++;
            college.setDepartmentsSize(departmentsSize);

            System.out.printf("%s department was added successfully.\n",departmentName);
        }

    }
    public static void addLecturerToDepartment(College college, String lecturerName, String departmentName) {
        Department department = college.getDepartment(departmentName);
        if (department != null) {
            Lecturer lecturer = college.getLecturer(lecturerName);
            if (lecturer != null) {
                String input = "";
                if(lecturer.getDepartment() != null) {
                    do {
                        System.out.printf("%s is already part of department. do you want to change his department? (yes / no): ", lecturerName);
                        Scanner sc = new Scanner(System.in);
                        input = sc.nextLine();
                    } while (!(input.equals("yes") || input.equals("no")));
                    System.out.println(input);
                    if (input.equals("yes")){
                        lecturer.getDepartment().removeLecturer(lecturer);
                    }
                    else System.out.println("lecturer has not been added to the department");
                }
                if (lecturer.getDepartment() == null || input.equals("yes")) {
                    department.addLecturer(lecturer);
                    lecturer.setDepartment(department);
                    System.out.printf("%s has been added to the department\n", lecturerName);

                }
            } else System.out.printf("%s does not exist.\n", lecturerName);
        } else System.out.printf("%s does not exist.\n", departmentName);
    }

    // Submitted By: Tamir Eliasy 216430298 & Ohad Gips 215426883
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter College Name: ");
        String collegeName = sc.nextLine();
        College college = new College(collegeName);
        int option;
        do {
            System.out.println("""
                    Welcome To The System:
                    0- Exit
                    1- Add a lecturer
                    2- Add a committee
                    3- Assign a lecturer to a committee
                    4- Assign a New Chairperson to a committee
                    5- Remove a lecturer from a committee
                    6- Add a study department
                    7- Add a lecturer to a study department
                    8- Show the average salary of all lecturers in college
                    9- Show the average salary of lecturers in a certain department
                    10- Show all lecturers information
                    11- Show all committees information""");
            option = sc.nextInt();
            String lecturerName, committeeName, departmentName;
            Committee committee;
            Lecturer lecturer;
            sc.nextLine();
            switch (option) {
                case 1:
                    addLecturer(college);
                    break;

                case 2:
                    addCommittee(college);
                    break;
                case 3:
                    System.out.print("Enter committee name: ");
                    committeeName = sc.nextLine();
                    committee = college.getCommittee(committeeName);
                    System.out.print("Enter lecturer name: ");
                    lecturerName = sc.nextLine();
                    lecturer = college.getLecturer(lecturerName);
                        if (LecturerAndCommitteeExists(lecturer, committee)) {
                            if (college.addLecturerToCommittee(committee, lecturer))
                                System.out.printf("%s has been added to the committee\n", lecturerName);
                            else
                                System.out.printf("%s already part of the committee\n.", lecturerName);
                        } else System.out.println("There is no lecturer with that name");
                    break;
                case 4:
                    System.out.print("Enter committee name: ");
                    committeeName = sc.nextLine();
                    System.out.print("Enter lecturer name: ");
                    lecturerName = sc.nextLine();
                    committee = college.getCommittee(committeeName);
                    lecturer = college.getLecturer(lecturerName);
                    if (LecturerAndCommitteeExists(lecturer, committee)) {
                        if (college.setNewChairperson(committee, lecturer))
                            System.out.printf("%s is now the chairperson of %s\n", lecturerName, committeeName);
                        else
                            System.out.printf("%s doesn't meet the requirements\n", lecturerName);
                    }
                    break;
                case 5:
                    System.out.print("Enter committee name: ");
                    committeeName = sc.nextLine();
                    System.out.print("Enter lecturer name: ");
                    lecturerName = sc.nextLine();
                    committee = college.getCommittee(committeeName);
                    lecturer = college.getLecturer(lecturerName);
                    if (LecturerAndCommitteeExists(lecturer,committee)) {
                        if(college.removeCommitteeMember(committee, lecturer))
                            System.out.printf("%s has been removed from %s\n", lecturerName, committeeName);
                        else
                            System.out.printf("%s has not been removed from %s\n",lecturerName,committeeName);
                    }
                    break;
                case 6:
                    addDepartment(college);
                    break;
                case 7:
                    System.out.print("Enter department name: ");
                    departmentName = sc.nextLine();
                    System.out.print("Enter lecturer name: ");
                    lecturerName = sc.nextLine();
                    addLecturerToDepartment(college,lecturerName, departmentName);
                    break;
                case 8:
                    System.out.printf("The average wage for lecturers in this college is: %s\n",college.salaryAverage(null));
                    break;
                case 9:
                    System.out.print("Enter department name: ");
                    departmentName = sc.nextLine();
                    Department department = college.getDepartment(departmentName);
                    if (department == null) {
                        System.out.printf("%s does not exist\n", departmentName);

                    }
                    else
                        System.out.printf("The average wage for lecturers in this department is: %s\n",college.salaryAverage(department));
                    break;
                case 10:
                    System.out.print(college.showDetailsLecturers());
                    break;
                case 11:
                    System.out.print(college.showDetailsComittees());
                    break;
                default:
                    System.out.println("Invalid input try again");
            }
        }while(option != 0);
        System.out.println("You have left the system");
    }
}