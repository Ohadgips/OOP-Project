package OhadGipsAndTamirEliasy;
import java.util.Scanner;

public class College {
    private String collegeName;
    private Lecturer[] lecturers;
    private Committee[] committees;
    private Department[] departments;
    private int committeeSize;
    private int lecturersSize;
    private int departmentsSize;

    public College(String collegeName) {
        setCollegeName(collegeName);
        this.lecturers = new Lecturer[1];
        committees = new Committee[1];
        departments = new Department[1];
        committeeSize = 0;
        lecturersSize = 0;
        departmentsSize = 0;
    }
    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public Lecturer getLecturer(String lecturerName) {
        for (int i = 0; i < lecturersSize; i++) {
            if (lecturers[i].getName().equals(lecturerName))
                return lecturers[i];
        }
        return null;
    }

    public Lecturer[] getLecturers() {
        return lecturers;
    }

    public Committee[] getCommittees() {
        return committees;
    }

    public void setCommittees(Committee[] committees) {
        this.committees = committees;
    }

    public Department[] getDepartments() {
        return departments;
    }

    public void setLecturers(Lecturer[] lecturers) {
        this.lecturers = lecturers;
    }

    public int getDepartmentsSize() {
        return departmentsSize;
    }

    public void setDepartments(Department[] departments) {
        this.departments = departments;
    }

    public int getCommitteeSize() {
        return committeeSize;
    }

    public void setCommitteeSize(int committeeSize) {
        this.committeeSize = committeeSize;
    }

    public int getLecturersSize() {
        return lecturersSize;
    }

    public void setLecturersSize(int lecturersSize) {
        this.lecturersSize = lecturersSize;
    }


    public void setDepartmentsSize(int departmentsSize) {
        this.departmentsSize = departmentsSize;
    }

    public Committee getCommittee(String committeeName) {
        for (int i = 0; i < committeeSize; i++) {
            if (committeeName.equals(committees[i].getName()))
                return committees[i];
        }
        return null;
    }
    public boolean addLecturerToCommittee(Committee committee, Lecturer lecturer) {
        if (!committee.getChairperson().getName().equals(lecturer.getName())) {
            if (committee.addLecturer(lecturer)) {
                lecturer.addCommittee(committee);
                return true;
            }
        }
        return false;
    }
    // set new chairperson - remove committee from chairperson list
    public boolean setNewChairperson(Committee committee,Lecturer lecturer) {
        if (committee.canBeChairperson(lecturer)) {
            if (!committee.removeLecturer(lecturer)) {
                lecturer.addCommittee(committee);
                committee.getChairperson().removeCommittee(committee);
            }
            if (committee.setChairperson(lecturer))
                return true;
        }
        return false;
    }
    public boolean HasDoctoralLecturer() {
        for (int i = 0; i < lecturersSize; i++) {
            if(lecturers[i].getKindOfDegree() == Lecturer.Degree.Doctoral)
                return true;
        }
        return false;
    }
    public boolean removeCommitteeMember(Committee committee,Lecturer lecturer) {
        if (committee.removeLecturer(lecturer)) {
            lecturer.removeCommittee(committee);
            return true;
        }
        return false;
    }

    public void resizeDepartments() {
        if (departmentsSize >= departments.length) {
            Department[] temp = new Department[departmentsSize * 2];
            for (int i = 0; i < departmentsSize; i++) {
                temp[i] = departments[i];
            }
            departments = temp;
        }
    }
    public Department getDepartment(String departmentName) {
        for (int i = 0; i < departmentsSize; i++) {
            if (departmentName.equals(departments[i].getName()))
                return departments[i];
        }
        return null;
    }

    public double salaryAverage(Department department){
        int salaryTotal = 0;
        int lectSize = 0;
        if (department != null) {
            lectSize = department.getLecturersSize();
            if (lectSize == 0) return 0;
            else {
                for (int j = 0; j < lectSize; j++) {
                    salaryTotal += department.getLecturers()[j].getWage();
                }
            }
        }
        else {
            lectSize = getLecturersSize();
            if (lectSize == 0)
                return 0;
            for (int i = 0; i < lectSize; i++) {
                salaryTotal += this.lecturers[i].getWage();
            }
        }
        return (double) salaryTotal / lectSize;
    }
    public String showDetailsLecturers(){
        String output = "Here all the lecturers:\n";
        for(int i = 0; i < lecturersSize; i++){
            output +=(lecturers[i].toString()+"\n\n");
        }
        return output;
    }
    public String showDetailsComittees() {
        String output = "Here all the committees:\n";
        for (int i = 0; i < committeeSize; i++) {
            output += committees[i].toString()+"\n\n";
        }
        return output;
    }

}
